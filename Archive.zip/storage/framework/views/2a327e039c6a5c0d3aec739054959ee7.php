<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Admin Panel'); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.0/css/all.min.css"
          integrity="sha512-DxV+EoADOkOygM4IR9yXP8Sb2qwgidEmeqAEmDKIOfPRQZOWbXCzLC6vjbZyy0vPisbH2SyW27+ddLVCN+OMzQ=="
          crossorigin="anonymous" referrerpolicy="no-referrer"/>

    <link rel="icon" href="<?php echo e(asset('favicon.ico')); ?>" type="image/x-icon">

</head>
<body class="flex">


<?php if (isset($component)) { $__componentOriginale842643f388f3f2a729c3cad188d3504 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale842643f388f3f2a729c3cad188d3504 = $attributes; } ?>
<?php $component = App\View\Components\Admin\Sidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Admin\Sidebar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale842643f388f3f2a729c3cad188d3504)): ?>
<?php $attributes = $__attributesOriginale842643f388f3f2a729c3cad188d3504; ?>
<?php unset($__attributesOriginale842643f388f3f2a729c3cad188d3504); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale842643f388f3f2a729c3cad188d3504)): ?>
<?php $component = $__componentOriginale842643f388f3f2a729c3cad188d3504; ?>
<?php unset($__componentOriginale842643f388f3f2a729c3cad188d3504); ?>
<?php endif; ?>


<div class="flex-1 p-6">
    <?php echo $__env->yieldContent('content'); ?>
</div>

</body>
</html>
<?php /**PATH /home/albert/Workspace/FoxSoft/ShopFood/resources/views/layouts/admin.blade.php ENDPATH**/ ?>