<?php $__env->startSection('content'); ?>
    <div class="p-6">

        <!-- User Table -->
        <h2 class="text-xl font-semibold mb-4">User List</h2>
        <table class="table-style">
            <thead class="bg-gray-100">
            <tr>
                <th>Email</th>
                <th>Ad</th>
                <th>Qeydiyyat tarixi</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <div class="flex items-center gap-3">
                            <img src="https://ui-avatars.com/api/?name=<?php echo e(urlencode($user->name)); ?>&background=random"
                                 class="w-10 h-10 rounded-full">
                            <div>
                                <p class="font-medium"><?php echo e($user->email); ?></p>
                                <p class="text-sm text-gray-500"><?php echo e($user->email); ?></p>
                            </div>
                        </div>
                    </td>
                    <td><?php echo e($user->contact_name); ?></td>
                    <td><?php echo e($user->created_at->format('d/m/Y')); ?></td>
                    <td>
                        <?php if($user->is_active): ?>
                            <span class="status-approved">Verified</span>
                        <?php elseif($user->is_send_email): ?>
                            <span class="status-sent">Mail sent</span>
                        <?php else: ?>
                            <span class="status-pending">Waiting</span>

                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="flex gap-2">
                            <?php if(!$user->email_verified_at): ?>
                                <form action="<?php echo e(route('admin.users.confirm', ['id'=>$user->id])); ?>" method="POST"
                                      style="display: inline;">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit"
                                            class="bg-green-500 hover:bg-green-600 text-white px-3 py-1 rounded text-sm">
                                        <?php if($user->is_send_email): ?>
                                            Resend
                                        <?php else: ?>
                                            Confirm
                                        <?php endif; ?>
                                    </button>
                                </form>
                            <?php endif; ?>

                            <a href="<?php echo e(route('admin.users.edit',['id'=>$user->id])); ?>"
                               class="bg-blue-500 hover:bg-blue-600 text-white px-3 py-1 rounded text-sm">
                                Edit
                            </a>

                            <a href="<?php echo e(route('user.details',['id'=>$user->id])); ?>"
                               class="bg-orange-500 hover:bg-orange-500 text-white px-3 py-1 rounded text-sm">
                                Details
                            </a>

                            <form action="<?php echo e(route('users.delete',['id'=>$user->id])); ?>" method="POST"
                                  style="display: inline;"
                                  onsubmit="return confirm('Bu istifadəçini silmək istədiyinizdən əminsiniz?')">
                                <?php echo csrf_field(); ?>
                                <button type="submit"
                                        class="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded text-sm">
                                    Delete
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <?php if($users->isEmpty()): ?>
            <div class="text-center py-8">
                <p class="text-gray-500">Heç bir istifadəçi tapılmadı.</p>
            </div>
        <?php endif; ?>
    </div>

    <style>
        .status-approved {
            background-color: #10b981;
            color: white;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 500;
        }

        .status-sent {
            background-color: #3B82F6;
            color: white;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 500;
        }

        .status-pending {
            background-color: #f59e0b;
            color: white;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 500;
        }

        .status-denied {
            background-color: #ef4444;
            color: white;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 500;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.dashboard.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/albert/Workspace/FoxSoft/ShopFood/resources/views/admin/dashboard/users.blade.php ENDPATH**/ ?>