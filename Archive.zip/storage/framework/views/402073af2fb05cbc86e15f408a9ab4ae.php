<?php $__env->startSection('content'); ?>
    <div class="max-w-full mx-auto py-10">
        <div class="bg-white shadow rounded-lg p-6">
            <h2 class="text-2xl font-bold mb-6">Exchange Rates</h2>

            
            <?php if(session('success')): ?>
                <div class="mb-4 p-4 bg-green-100 text-green-700 rounded-lg">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="mb-4 p-4 bg-red-100 text-red-700 rounded-lg">
                    <ul class="list-disc pl-5">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            
            <div class="overflow-x-auto rounded-lg border border-gray-200">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Currency</th>
                        <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Rate</th>
                        <th class="px-6 py-3 text-center text-sm font-semibold text-gray-600">Actions</th>
                    </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                    <?php $__empty_1 = true; $__currentLoopData = $rates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-gray-50 transition">
                            <td class="px-6 py-3 font-medium text-gray-800"><?php echo e($rate->currency); ?></td>
                            <td class="px-6 py-3 text-gray-700"><?php echo e(number_format($rate->rate, 2)); ?></td>
                            <td class="px-6 py-3 text-center">
                                <button onclick="openUpdateModal(<?php echo e($rate->id); ?>, '<?php echo e($rate->currency); ?>', '<?php echo e($rate->rate); ?>')"
                                        class="px-4 py-1.5 bg-yellow-500 text-white rounded-md hover:bg-yellow-600 transition">
                                    Update
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="3" class="px-6 py-4 text-center text-gray-500">No exchange rates found.</td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    
    <div id="updateRateModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div class="bg-white w-full max-w-md rounded-lg shadow-lg p-6">
            <h3 class="text-lg font-bold mb-4">Update Exchange Rate</h3>
            <form id="updateRateForm" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="mb-4">
                    <label class="block text-sm mb-2">Currency</label>
                    <input type="text" id="updateCurrency" name="currency" class="w-full border rounded px-3 py-2 bg-gray-100" readonly>
                </div>
                <div class="mb-4">
                    <label class="block text-sm mb-2">Rate</label>
                    <input type="number" step="0.01" id="updateRate" name="rate" class="w-full border rounded px-3 py-2 focus:ring focus:ring-yellow-200">
                </div>
                <div class="flex justify-end space-x-2">
                    <button type="button" onclick="closeUpdateModal()" class="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400">Cancel</button>
                    <button type="submit" class="px-4 py-2 bg-yellow-600 text-white rounded hover:bg-yellow-700">Update</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function openUpdateModal(id, currency, rate) {
            const modal = document.getElementById('updateRateModal');
            modal.classList.remove('hidden');

            document.getElementById('updateCurrency').value = currency;
            document.getElementById('updateRate').value = rate;
            document.getElementById('updateRateForm').action = `/exchange-rates/${id}`;
        }

        function closeUpdateModal() {
            document.getElementById('updateRateModal').classList.add('hidden');
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.dashboard.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/albert/Workspace/FoxSoft/ShopFood/resources/views/admin/currency/index.blade.php ENDPATH**/ ?>