<?php $__env->startSection('content'); ?>
    <div class="max-w-full mx-auto py-10">
        <div class="bg-white shadow-lg rounded-xl p-6">

            
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6 border-b pb-4">
                <h2 class="text-3xl font-bold text-gray-800">User Details</h2>
                <span class="text-sm text-gray-500">ID: <?php echo e($user->id); ?></span>
            </div>

            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                <div class="p-4 bg-gray-50 rounded-lg">
                    <p class="text-gray-500 text-sm">Name</p>
                    <p class="text-lg font-semibold"><?php echo e($user->contact_name); ?></p>
                </div>
                <div class="p-4 bg-gray-50 rounded-lg">
                    <p class="text-gray-500 text-sm">Email</p>
                    <p class="text-lg font-semibold"><?php echo e($user->email); ?></p>
                </div>
                <div class="p-4 bg-gray-50 rounded-lg">
                    <p class="text-gray-500 text-sm">Registered</p>
                    <p class="text-lg font-semibold"><?php echo e($user->created_at->format('Y-m-d')); ?></p>
                </div>
                <div class="p-4 bg-gray-50 rounded-lg">
                    <p class="text-gray-500 text-sm">Status</p>
                    <span class="px-3 py-1 rounded-full text-sm font-medium
                    <?php echo e($user->is_active ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'); ?>">
                    <?php echo e($user->is_active ? 'Active' : 'Inactive'); ?>

                </span>
                </div>
            </div>

            
            <h3 class="text-2xl font-semibold text-gray-800 mb-4">Orders</h3>
            <div class="overflow-x-auto">
                <table class="w-full border border-gray-200 rounded-lg overflow-hidden">
                    <thead class="bg-gray-100">
                    <tr>
                        <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Order ID</th>
                        <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Status</th>
                        <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Payment</th>
                        <th class="px-6 py-3 text-left text-sm font-semibold text-gray-600">Date</th>
                        <th class="px-6 py-3 text-center text-sm font-semibold text-gray-600">Actions</th>
                    </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200 bg-white">
                    <?php $__empty_1 = true; $__currentLoopData = $user->orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-gray-50">
                            <td class="px-6 py-4 font-medium text-gray-800">#<?php echo e($order->order_number); ?></td>
                            <td class="px-6 py-4">
                                <span class="px-3 py-1 rounded-full text-sm font-medium
                                    <?php switch($order->status):
                                        case ('pending'): ?> bg-orange-100 text-orange-700 <?php break; ?>
                                        <?php case ('processing'): ?> bg-blue-100 text-blue-700 <?php break; ?>
                                        <?php case ('shipped'): ?> bg-yellow-100 text-yellow-700 <?php break; ?>
                                        <?php case ('delivered'): ?> bg-green-100 text-green-700 <?php break; ?>
                                        <?php case ('cancelled'): ?> bg-red-100 text-red-700 <?php break; ?>
                                        <?php default: ?> bg-gray-100 text-gray-700
                                    <?php endswitch; ?>">
                                    <?php echo e(ucfirst($order->status ?? 'N/A')); ?>

                                </span>
                            </td>
                            <td class="px-6 py-4">
                                <span class="px-2 py-1 rounded-md bg-gray-100 text-gray-700 text-sm">
                                    <?php echo e(ucfirst($order->payment_method ?? 'N/A')); ?>

                                </span>
                            </td>
                            <td class="px-6 py-4 text-gray-600"><?php echo e($order->created_at->format('Y-m-d')); ?></td>
                            <td class="px-6 py-4 text-center">
                                <a href="<?php echo e(route('admin.orders.show', $order->id)); ?>"
                                   class="inline-block px-4 py-2 bg-indigo-600 text-white text-sm font-medium rounded-lg shadow hover:bg-indigo-700 transition">
                                    View
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="px-6 py-4 text-center text-gray-500">No orders found.</td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.dashboard.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/albert/Workspace/FoxSoft/ShopFood/resources/views/admin/users/show.blade.php ENDPATH**/ ?>