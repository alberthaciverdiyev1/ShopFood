<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shop Food - Вход для предпринимателей</title>
    <style>
        :root {
            --primary: #2E7D32;
            --primary-light: #4CAF50;
            --secondary: #FFD700;
            --background: #F8F9FA;
            --text: #333333;
            --text-light: #6C757D;
            --white: #FFFFFF;
            --border: #E0E0E0;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: var(--background);
            color: var(--text);
            min-height: 100vh;
            display: flex;
            align-items: center;
        }

        .container {
            display: flex;
            max-width: 1200px;
            margin: 0 auto;
            background-color: var(--white);
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }

        .left-panel {
            flex: 1;
            background-color: var(--primary);
            padding: 40px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            color: var(--white);
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 60px;
        }

        .logo img {
            height: 40px;
        }

        .logo span {
            font-size: 24px;
            font-weight: 700;
        }

        .image-box img {
            width: 100%;
            max-height: 400px;
            object-fit: contain;
        }

        .right-panel {
            flex: 1;
            padding: 60px 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        h2 {
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 8px;
            color: var(--text);
        }

        .subtitle {
            color: var(--text-light);
            margin-bottom: 32px;
            font-size: 14px;
        }

        .login-form {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .input-group {
            position: relative;
            display: flex;
            align-items: center;
            border: 1px solid var(--border);
            border-radius: 8px;
            overflow: hidden;
        }

        .input-group:focus-within {
            border-color: var(--primary);
            box-shadow: 0 0 0 2px rgba(46, 125, 50, 0.2);
        }

        .icon {
            padding: 0 16px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .icon img {
            width: 18px;
            height: 18px;
            opacity: 0.7;
        }

        input {
            flex: 1;
            padding: 14px 16px 14px 0;
            border: none;
            outline: none;
            font-size: 15px;
        }

        input::placeholder {
            color: var(--text-light);
            opacity: 0.7;
        }

        .toggle-password {
            padding: 0 16px;
            cursor: pointer;
        }

        .toggle-password img {
            width: 18px;
            height: 18px;
            opacity: 0.7;
        }

        .btn {
            padding: 14px;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            border: none;
        }

        .primary {
            background-color: var(--primary);
            color: var(--white);
        }

        .primary:hover {
            background-color: var(--primary-light);
        }

        .secondary {
            background-color: transparent;
            color: var(--primary);
            border: 1px solid var(--primary);
        }

        .secondary:hover {
            background-color: rgba(46, 125, 50, 0.1);
        }

        @media (max-width: 768px) {
            .container {
                flex-direction: column;
                margin: 20px;
            }

            .left-panel {
                padding: 30px;
            }

            .logo {
                margin-bottom: 30px;
            }

            .image-box {
                display: none;
            }

            .right-panel {
                padding: 40px 30px;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <!-- Left Panel -->
    <div class="left-panel">
        <div class="logo">
            <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Shop Food Logo">
            <span>SHOP FOOD</span>
        </div>
        <div class="image-box">
            <img src="<?php echo e(asset('images/login_decorative.png')); ?>" alt="Food Wholesale Illustration">
        </div>
    </div>

    <!-- Right Panel -->
    <div class="right-panel">
        <h2>Продажа только зарегистрированным предпринимателям</h2>
        <p class="subtitle">Пожалуйста, войдите</p>
        <form action="#" method="post" class="login-form">
            <div class="input-group">
                <span class="icon">
                    <img src="<?php echo e(asset('images/user-icon.svg')); ?>" alt="Username">
                </span>
                <input type="text" placeholder="Имя пользователя" required>
            </div>
            <div class="input-group">
                <span class="icon">
                    <img src="<?php echo e(asset('images/lock-icon.svg')); ?>" alt="Password">
                </span>
                <input type="password" placeholder="Пароль" required>
                <span class="toggle-password">
                    <img src="<?php echo e(asset('images/eye-icon.svg')); ?>" alt="Show Password">
                </span>
            </div>
            <button type="submit" class="btn primary">Войти</button>
            <button type="button" class="btn secondary">Зарегистрироваться</button>
        </form>
    </div>
</div>
</body>
</html>
<?php /**PATH /home/albert/Workspace/ShopFood/resources/views/pages/auth/login.blade.php ENDPATH**/ ?>