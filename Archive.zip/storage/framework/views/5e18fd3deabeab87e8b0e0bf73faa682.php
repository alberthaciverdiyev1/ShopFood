<!DOCTYPE html>
<html>
<head>
    <title>Exchange Rates</title>
</head>
<body>
<h1>Exchange Rates</h1>

<?php if(session('success')): ?>
    <p style="color:green"><?php echo e(session('success')); ?></p>
<?php endif; ?>

<table border="1" cellpadding="5">
    <tr>
        <th>Currency</th>
        <th>Rate</th>
        <th>Action</th>
    </tr>
    <?php $__currentLoopData = $rates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($rate->currency); ?></td>
            <td><?php echo e($rate->rate); ?></td>
            <td><a href="<?php echo e(route('exchange-rates.edit', $rate->id)); ?>">Edit</a></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</body>
</html>
<?php /**PATH /home/albert/Workspace/FoxSoft/ShopFood/resources/views/exchange_rates/index.blade.php ENDPATH**/ ?>