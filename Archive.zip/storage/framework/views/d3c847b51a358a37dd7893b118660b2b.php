<?php $__env->startSection('content'); ?>
    <div class="max-w-full mx-auto py-10">
        <div class="bg-white shadow rounded-lg p-6">
            <h2 class="text-2xl font-bold mb-6">Settings</h2>

            
            <?php if(session('success')): ?>
                <div class="mb-4 p-4 bg-green-100 text-green-700 rounded-lg">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="mb-4 p-4 bg-red-100 text-red-700 rounded-lg">
                    <ul class="list-disc pl-5">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form action="<?php echo e(route('setting.update')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    
                    <div>
                        <label for="whatsapp_link" class="block text-sm font-medium text-gray-700 mb-2">WhatsApp Link</label>
                        <input type="url" id="whatsapp_link" name="whatsapp_link"
                               value="<?php echo e(old('whatsapp_link', $setting->whatsapp_link ?? '')); ?>"
                               class="w-full border rounded px-3 py-2 focus:ring focus:ring-indigo-200">
                    </div>

                    
                    <div>
                        <label for="telegram_link" class="block text-sm font-medium text-gray-700 mb-2">Telegram Link</label>
                        <input type="url" id="telegram_link" name="telegram_link"
                               value="<?php echo e(old('telegram_link', $setting->telegram_link ?? '')); ?>"
                               class="w-full border rounded px-3 py-2 focus:ring focus:ring-indigo-200">
                    </div>
                </div>

                <div class="flex justify-end">
                    <button type="submit"
                            class="px-5 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition">
                        Save Changes
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.dashboard.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/albert/Workspace/FoxSoft/ShopFood/resources/views/admin/setting/index.blade.php ENDPATH**/ ?>