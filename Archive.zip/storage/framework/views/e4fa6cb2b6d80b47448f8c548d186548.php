<?php $__env->startSection('content'); ?>
    <div class="p-6">
        <h2 class="text-2xl font-bold mb-4">Orders</h2>

        <div class="overflow-x-auto">
            <table class="w-full border-collapse bg-white shadow-md rounded-lg overflow-hidden">
                <thead class="bg-gray-100 text-gray-700">
                <tr>
                    <th class="px-4 py-3 text-left">Order #</th>
                    <th class="px-4 py-3 text-left">Status</th>
                    <th class="px-4 py-3 text-left">Total Price</th>
                    <th class="px-4 py-3 text-left">Date</th>
                    <th class="px-4 py-3 text-left">Items</th>
                </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="hover:bg-gray-50">
                        <td class="px-4 py-3 font-semibold text-gray-800">
                            <?php echo e($order['order_number']); ?>

                        </td>
                        <td class="px-4 py-3">
                            <select class="status-select border rounded px-2 py-1 text-sm"
                                    data-order-id="<?php echo e($order['order_id']); ?>">
                                <?php
                                    $statuses = ['pending', 'processing', 'shipped', 'delivered', 'cancelled', 'returned'];
                                ?>
                                <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($status); ?>"
                                        <?php echo e($order['status'] === $status ? 'selected' : ''); ?>>
                                        <?php echo e(ucfirst($status)); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </td>
                        <td class="px-4 py-3">
                            <?php echo e($order['total_price'] ?? '-'); ?>

                        </td>
                        <td class="px-4 py-3 text-sm text-gray-600">
                            <?php echo e(\Carbon\Carbon::parse($order['created_at'])->format('Y-m-d H:i')); ?>

                        </td>
                        <td class="px-4 py-3">
                            <div class="flex flex-wrap gap-3">
                                <?php $__currentLoopData = $order['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="flex items-center gap-2 bg-gray-100 px-2 py-1 rounded-lg">
                                        <img src="<?php echo e($item['product']['images'][0] ?? ''); ?>"
                                             alt="<?php echo e($item['product']['nazev'] ?? ''); ?>"
                                             class="w-10 h-10 object-cover rounded">
                                        <span class="text-sm">
                                            <?php echo e($item['product']['nazev'] ?? ''); ?>

                                            <span class="text-gray-500">(x<?php echo e($item['quantity']); ?>)</span>
                                        </span>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

            function applyStatusColor(select) {
                select.classList.remove(
                    "bg-orange-500", "bg-blue-500", "bg-yellow-500",
                    "bg-green-500", "bg-red-500", "bg-purple-500",
                    "text-white"
                );

                switch (select.value) {
                    case "pending":
                        select.classList.add("bg-orange-500", "text-white");
                        break;
                    case "processing":
                        select.classList.add("bg-blue-500", "text-white");
                        break;
                    case "shipped":
                        select.classList.add("bg-yellow-500", "text-white");
                        break;
                    case "delivered":
                        select.classList.add("bg-green-500", "text-white");
                        break;
                    case "cancelled":
                        select.classList.add("bg-red-500", "text-white");
                        break;
                    case "returned":
                        select.classList.add("bg-purple-500", "text-white");
                        break;
                }
            }

            document.querySelectorAll(".status-select").forEach(select => {
                applyStatusColor(select);

                select.addEventListener("change", function () {
                    const orderId = this.dataset.orderId;
                    const status = this.value;

                    applyStatusColor(this);

                    fetch(`/admin/order/${orderId}`, {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json",
                            "X-CSRF-TOKEN": csrfToken,
                        },
                        body: JSON.stringify({ status }),
                    })
                        .then(res => res.json())
                        .then(data => {
                            if (data.success === 200) {
                                alert("✅ Order status updated: " + status);
                            } else {
                                alert("❌ Error updating order.");
                            }
                        })
                        .catch(() => alert("❌ Network error."));
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.dashboard.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/albert/Workspace/FoxSoft/ShopFood/resources/views/admin/order.blade.php ENDPATH**/ ?>