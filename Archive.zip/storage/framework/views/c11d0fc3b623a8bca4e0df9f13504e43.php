<?php $__env->startSection('content'); ?>
    <?php
        $hideNavbar = true;
    ?>

    <div class="min-h-screen pt-5 bg-gray-200 flex items-center justify-center">
        <div class="w-full max-w-6xl bg-white rounded-lg shadow-lg flex overflow-hidden">

            <div class="w-1/2 bg-gray-200 flex flex-col items-start p-8">
                <div class="flex items-center mb-4">
                    <img src="<?php echo e(asset('/images/logo.png')); ?>" alt="Logo" class="w-[140px] h-10 mr-2">
                </div>

                <div class="w-full flex justify-center">
                    <img src="<?php echo e(asset('/images/login-left.png')); ?>" alt="Left Image"
                         class="rounded-lg shadow-lg object-cover">
                </div>

            </div>

            <div class="w-1/2 bg-white px-[120px] py-[100px] flex flex-col justify-center">
                <h2 class="text-3xl font-semibold text-center"
                    style="color: #333333; line-height: 100%; margin-bottom: 80px;">
                    Продажа только зарегистрированным предпринимателям
                </h2>

                <p class="text-center font-bold" style="color: #331111; margin-bottom: 20px;">
                    Пожалуйста, войдите
                </p>

                <form method="POST" action="<?php echo e(route('login')); ?>" class="flex flex-col space-y-4">
                    <?php echo csrf_field(); ?>

                    <div class="flex items-center rounded-lg px-3 py-3"
                         style="background-color: #F9F9F9; border: 1px solid #CED4DA;">
                        <i class="fas fa-user mr-3" style="color: black;"></i>
                        <input type="text" name="email" placeholder="Имя пользователя"
                               class="w-full outline-none placeholder-gray-500 text-sm bg-transparent" required>
                    </div>

                    <div class="flex items-center rounded-lg px-3 py-3 relative"
                         style="background-color: #F9F9F9; border: 1px solid #CED4DA;">
                        <i class="fas fa-lock mr-3" style="color: black;"></i>
                        <input type="password" name="password" placeholder="Пароль"
                               class="w-full outline-none placeholder-gray-500 text-sm bg-transparent" required>
                        <i class="fas fa-eye cursor-pointer absolute right-3" style="color: black;"></i>
                    </div>
                    <?php if($errors->any()): ?>
                        <div class="mb-4 p-3 bg-red-100 text-red-700 rounded">
                            <ul class="list-disc pl-5">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <button type="submit"
                            class="w-full py-3 mt-3 text-white rounded-lg hover:bg-[#2b0909] transition"
                            style="background-color: #3D0C0C;">
                        Войти
                    </button>

                    <a href="<?php echo e(route('web:register')); ?>"
                       class="w-full py-3 mt-3 text-center rounded-lg transition block"
                       style="border: 1px solid #3D0C0C; color: #3D0C0C; background-color: white;"
                       onmouseover="this.style.backgroundColor='#2b0909'; this.style.color='white';"
                       onmouseout="this.style.backgroundColor='white'; this.style.color='#3D0C0C';">
                        Зарегистрироваться
                    </a>

                </form>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/albert/Workspace/FoxSoft/ShopFood/resources/views/login.blade.php ENDPATH**/ ?>