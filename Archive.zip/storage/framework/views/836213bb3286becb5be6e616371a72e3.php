<div class="mx-auto px-4 py-6">
    <div class="flex justify-between items-center ">
        <h3 class="mt-5 text-2xl font-bold">Предложения</h3>
        <div class="text-md font-bold text-gray-400 hover:underline
    ">See more </div>
    </div>

    <div id="" class="cards grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6 mt-6">
       <?php $__currentLoopData = array_slice($products,0,6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


       
    <div 
        class="card openModal relative bg-white rounded-3xl p-4 flex flex-col items-center text-center shadow-md hover:shadow-lg transition duration-300"
        data-id="<?php echo e($product['id']); ?>"
        data-title="<?php echo e($product['title']); ?>"
        data-price="<?php echo e($product['price']); ?>"
        data-image="<?php echo e($product['images'][0] ?? $product['image']); ?>"
        data-description="<?php echo e($product['description']); ?>"
    >

    
        <img src="<?php echo e($product['images'][0] ?? $product['image']); ?>" alt="<?php echo e($product['title']); ?>" class="w-25 h-25 object-contain mt-4">
        
        <div class="absolute top-0 right-0 bg-orange-100 rounded-full w-10 h-10 flex items-center justify-center">
                <img src="<?php echo e(asset('/images/plusbg.png')); ?>" alt="">
                <span class=" absolute top-1 right-3 text-orange-500 z-3 text-xl font-bold">+</span>
            </div>
        <div class="text-start gap-3 pt-3 flex flex-col">
            <p class="price font-bold text-[#E00034] text-2xl mt-2">
                $<?php echo e($product['price']); ?>

            </p>
            <div class="desc font-bold text-sm mt-1">
                <?php echo e($product['title']); ?>

            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>



    <?php if (isset($component)) { $__componentOriginal88eb2b56a8cd034637f7d048f75632a3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal88eb2b56a8cd034637f7d048f75632a3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal-product-details','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal-product-details'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal88eb2b56a8cd034637f7d048f75632a3)): ?>
<?php $attributes = $__attributesOriginal88eb2b56a8cd034637f7d048f75632a3; ?>
<?php unset($__attributesOriginal88eb2b56a8cd034637f7d048f75632a3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal88eb2b56a8cd034637f7d048f75632a3)): ?>
<?php $component = $__componentOriginal88eb2b56a8cd034637f7d048f75632a3; ?>
<?php unset($__componentOriginal88eb2b56a8cd034637f7d048f75632a3); ?>
<?php endif; ?>
</div><?php /**PATH /home/albert/Workspace/ShopFood/resources/views/components/suggestions.blade.php ENDPATH**/ ?>