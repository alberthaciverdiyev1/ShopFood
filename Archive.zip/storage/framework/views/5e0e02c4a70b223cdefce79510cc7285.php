<?php $__env->startSection('content'); ?>

<div class="container mx-auto px-4 py-8 ">
  <h2 class="text-2xl font-bold"><?php echo app('translator')->get('Favorites'); ?></h2>
  <div class="flex gap-8 mt-4">
      <div class="w-[15%]"> </div>

      <div class="w-[68%] border border-[#999999] p-4 rounded-2xl">
      <h3 class="text-[#331111] font-semibold  text-xl ">Your favorite products</h3>

          <?php $__currentLoopData = $favorites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="favorite-row flex gap-4 justify-between items-center pb-4 mb-4">

                  <div class="flex gap-4 items-center">
                      <div class="checkbox-wrapper-23">
                          <h2 class="font-bold text-lg">
                              <?php echo e($index+1); ?>

                          </h2>
                      </div>
                      <img src="<?php echo e($item['product']['images'][0]); ?>" alt="<?php echo e($item['product']['nazev']); ?>" class="w-24 h-24 object-contain mt-4">
                      <div>
                          <h3 class="font-bold text-lg"><?php echo e($item['product']['nazev']); ?></h3>
                          <p class="text-gray-600">Some description about the product. It is very good and useful.</p>
                          <p class="text-red-500 font-bold mt-2">$<?php echo e($item['product']['cenaZaklVcDph']); ?></p>
                      </div>
                  </div>

                  <div class="flex gap-4 items-center">
                      <div class="bg-white px-2 py-2 rounded-xl border border-[#FAD399] cursor-pointer remove-favorite"
                           data-product-id="<?php echo e($item['product']['id']); ?>">
                          <img class="w-6 h-6 " src="<?php echo e(asset('/images/trash.png')); ?>" alt="">
                      </div>
                  </div>

              </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    <div class="w-[15%]"> </div>

  </div>
  <?php if (isset($component)) { $__componentOriginal453114ea3745bb5096b7cd8392a50b14 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal453114ea3745bb5096b7cd8392a50b14 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.suggestions','data' => ['products' => $products]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('suggestions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['products' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($products)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal453114ea3745bb5096b7cd8392a50b14)): ?>
<?php $attributes = $__attributesOriginal453114ea3745bb5096b7cd8392a50b14; ?>
<?php unset($__attributesOriginal453114ea3745bb5096b7cd8392a50b14); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal453114ea3745bb5096b7cd8392a50b14)): ?>
<?php $component = $__componentOriginal453114ea3745bb5096b7cd8392a50b14; ?>
<?php unset($__componentOriginal453114ea3745bb5096b7cd8392a50b14); ?>
<?php endif; ?>

</div>

<?php $__env->stopSection(); ?>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const removeBtns = document.querySelectorAll('.remove-favorite');

        removeBtns.forEach(btn => {
            btn.addEventListener('click', async function () {
                const productId = this.dataset.productId;
                const row = this.closest('.favorite-row'); // satırı seç

                try {
                    const response = await fetch(`/favorites/delete/${productId}`, {
                        method: 'DELETE',
                        headers: {
                            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                            'Accept': 'application/json',
                        }
                    });

                    const data = await response.json();

                    if (response.ok) {
                        row.remove(); // satırı DOM'dan sil
                        // Navbar favori sayısını güncelle
                        const favCountEl = document.getElementById('favoriteCount');
                        if (favCountEl) {
                            let favCount = parseInt(favCountEl.textContent);
                            favCountEl.textContent = favCount > 0 ? favCount - 1 : 0;
                        }
                    } else {
                        console.error(data.message || 'Error removing favorite.');
                    }

                } catch (error) {
                    console.error('Request failed:', error);
                }
            });
        });
    });
</script>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/albert/Workspace/FoxSoft/ShopFood/resources/views/favorites.blade.php ENDPATH**/ ?>