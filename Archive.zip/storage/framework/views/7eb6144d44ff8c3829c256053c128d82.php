<?php $__env->startSection('content'); ?>
    <div class="p-6 space-y-6">

        
        <div class="flex items-center justify-between">
            <h2 class="text-3xl font-bold">Order <?php echo e($order->order_number); ?></h2>
            <span class="text-gray-500 text-sm">Created at: <?php echo e($order->created_at->format('Y-m-d H:i')); ?></span>
        </div>

        
        <div class="bg-white shadow rounded-xl p-5">
            <h3 class="font-semibold text-lg mb-3 border-b pb-2"> User Information</h3>
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <p><strong>Name:</strong> <?php echo e($order->user->name ?? $order->user->contact_name); ?></p>
                <p><strong>Email:</strong> <?php echo e($order->user->email); ?></p>
                <p><strong>Phone:</strong> <?php echo e($order->user->contact_phone ?? '-'); ?></p>
            </div>
        </div>

        
        <div class="bg-white shadow rounded-xl p-5">
            <h3 class="font-semibold text-lg mb-3 border-b pb-2">Shipping Address</h3>
            <p class="text-gray-700"><?php echo e($order->address->street); ?>, <?php echo e($order->address->city); ?></p>
            <p class="text-gray-700"><?php echo e($order->address->zip); ?></p>
            <p class="text-gray-500 text-sm">Working Hours: <?php echo e($order->address->working_hours); ?></p>
        </div>

        
        <div class="bg-white shadow rounded-xl p-5">
            <h3 class="font-semibold text-lg mb-3 border-b pb-2">Order Items</h3>
            <div class="divide-y">
                <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $product = $item->product; ?>
                    <?php if($product): ?>
                        <div class="flex items-center gap-4 py-4">
                            <img src="<?php echo e($product['images'][0] ?? ''); ?>"
                                 alt="<?php echo e($product['nazev'] ?? ''); ?>"
                                 class="w-20 h-20 object-cover rounded-lg border">
                            <div class="flex-1">
                                <p class="font-semibold text-md"><?php echo e($product['nazev'] ?? ''); ?></p>
                                <p class="text-gray-500 text-sm">Quantity: x<?php echo e($item->quantity); ?></p>
                                <p class="text-gray-500 text-sm">Price: <?php echo e($item->price); ?></p>
                            </div>
                            <div class="text-right">
                                <p class="font-bold"><?php echo e($item['total'] ?? '-'); ?> $</p>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        
        <?php if(!empty($order->note_to_admin)): ?>
            <div class="bg-white shadow rounded-xl p-5">
                <h3 class="font-semibold text-lg mb-3 border-b pb-2">Note to Admin</h3>
                <p class="text-gray-700"><?php echo e($order->note_to_admin); ?></p>
            </div>
        <?php endif; ?>

        
        <div class="bg-white shadow rounded-xl p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
            <div>
                <h3 class="font-semibold text-lg">Total Price</h3>
                <p class="text-2xl font-bold mt-1"><?php echo e($order->total_price ?? '-'); ?> $</p>
            </div>

            <div>
                <h3 class="font-semibold text-lg">Status</h3>
                <select id="orderStatus" class="status-select border rounded px-3 py-2 mt-1" data-order-id="<?php echo e($order->id); ?>">
                    <?php
                        $statuses = ['pending', 'processing', 'shipped', 'delivered', 'cancelled', 'returned'];
                    ?>
                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($status); ?>" <?php echo e($order->status === $status ? 'selected' : ''); ?>>
                            <?php echo e(ucfirst($status)); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
            const statusSelect = document.getElementById('orderStatus');

            function applyStatusColor(select) {
                select.classList.remove("bg-orange-500","bg-blue-500","bg-yellow-500","bg-green-500","bg-red-500","bg-purple-500","text-white");
                switch(select.value) {
                    case "pending": select.classList.add("bg-orange-500","text-white"); break;
                    case "processing": select.classList.add("bg-blue-500","text-white"); break;
                    case "shipped": select.classList.add("bg-yellow-500","text-white"); break;
                    case "delivered": select.classList.add("bg-green-500","text-white"); break;
                    case "cancelled": select.classList.add("bg-red-500","text-white"); break;
                    case "returned": select.classList.add("bg-purple-500","text-white"); break;
                }
            }

            applyStatusColor(statusSelect);

            statusSelect.addEventListener("change", function() {
                const orderId = this.dataset.orderId;
                const status = this.value;

                applyStatusColor(this);

                fetch(`/admin/order/${orderId}`, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "X-CSRF-TOKEN": csrfToken
                    },
                    body: JSON.stringify({ status })
                })
                    .then(res => res.json())
                    .then(data => {
                        if(data.success === 200) {
                            alert("✅ Order status updated: " + status);
                        } else {
                            alert("❌ Error updating order.");
                        }
                    })
                    .catch(() => alert("❌ Network error."));
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.dashboard.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/albert/Workspace/FoxSoft/ShopFood/resources/views/admin/order/details.blade.php ENDPATH**/ ?>