<?php $__env->startSection('content'); ?>
    <div class="container mx-auto px-4 py-8">
        <h2 class="text-2xl font-bold mb-6">Privacy Policy</h2>

        <div class="bg-white shadow-md rounded-2xl p-6">
            <?php if(!empty($policy->content)): ?>
                <div class="prose max-w-full">
                    <?php echo $policy->content; ?>

                </div>
            <?php else: ?>
                <p class="text-gray-600">Privacy policy content is not available at the moment.</p>
            <?php endif; ?>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/albert/Workspace/FoxSoft/ShopFood/resources/views/privacy_policy/index.blade.php ENDPATH**/ ?>