<table border="1">
    <tr>
        <th>Email</th>
        <th>Action</th>
    </tr>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($user->email); ?></td>
            <td>
                <?php if($user->is_active == 1): ?>
                    <form action="<?php echo e(route('admin.users.toggle', ['id'=>$user->id])); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit" style="background:red; color:white;">Deactivate</button>
                    </form>
                <?php elseif($user->is_active == 0 && $user->is_send_email == 0): ?>
                    <form action="<?php echo e(route('admin.users.toggle', ['id'=>$user->id])); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit" style="background:green; color:white;">Activate</button>
                    </form>
                <?php elseif($user->is_active == 0 && $user->is_send_email == 1): ?>
                    <button style="background:orange; color:white;" disabled>Pending</button>
                <?php endif; ?>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php /**PATH /home/albert/Workspace/FoxSoft/ShopFood/resources/views/admin/users/index.blade.php ENDPATH**/ ?>