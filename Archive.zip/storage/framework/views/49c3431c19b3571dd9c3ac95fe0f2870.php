<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Shop Food</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/welcome.css')); ?>">
</head>
<body>

<div class="container">
    <div class="card">
        <div class="logo">
            <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Shop Food Logo">
        </div>
        <h1><?php echo app('translator')->get('Welcome'); ?></h1>
        <a href="<?php echo e(route('web:register')); ?>" class="btn"><?php echo app('translator')->get("Register"); ?></a>
        <a href="<?php echo e(route('login')); ?>" class="btn"><?php echo app('translator')->get("Login"); ?></a>
    </div>
</div>

</body>
</html>
<?php /**PATH /home/albert/Workspace/FoxSoft/ShopFood/resources/views/welcome.blade.php ENDPATH**/ ?>