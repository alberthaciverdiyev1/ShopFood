<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('components.hero', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('components.catalog', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('components.menu-banner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php if (isset($component)) { $__componentOriginal453114ea3745bb5096b7cd8392a50b14 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal453114ea3745bb5096b7cd8392a50b14 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.suggestions','data' => ['products' => $products]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('suggestions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['products' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($products)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal453114ea3745bb5096b7cd8392a50b14)): ?>
<?php $attributes = $__attributesOriginal453114ea3745bb5096b7cd8392a50b14; ?>
<?php unset($__attributesOriginal453114ea3745bb5096b7cd8392a50b14); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal453114ea3745bb5096b7cd8392a50b14)): ?>
<?php $component = $__componentOriginal453114ea3745bb5096b7cd8392a50b14; ?>
<?php unset($__componentOriginal453114ea3745bb5096b7cd8392a50b14); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal99ca81ad24cd758db0d83aa8f230b7d5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal99ca81ad24cd758db0d83aa8f230b7d5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.advertisement-product','data' => ['products' => $products]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('advertisement-product'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['products' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($products)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal99ca81ad24cd758db0d83aa8f230b7d5)): ?>
<?php $attributes = $__attributesOriginal99ca81ad24cd758db0d83aa8f230b7d5; ?>
<?php unset($__attributesOriginal99ca81ad24cd758db0d83aa8f230b7d5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99ca81ad24cd758db0d83aa8f230b7d5)): ?>
<?php $component = $__componentOriginal99ca81ad24cd758db0d83aa8f230b7d5; ?>
<?php unset($__componentOriginal99ca81ad24cd758db0d83aa8f230b7d5); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal453114ea3745bb5096b7cd8392a50b14 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal453114ea3745bb5096b7cd8392a50b14 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.suggestions','data' => ['products' => $products]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('suggestions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['products' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($products)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal453114ea3745bb5096b7cd8392a50b14)): ?>
<?php $attributes = $__attributesOriginal453114ea3745bb5096b7cd8392a50b14; ?>
<?php unset($__attributesOriginal453114ea3745bb5096b7cd8392a50b14); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal453114ea3745bb5096b7cd8392a50b14)): ?>
<?php $component = $__componentOriginal453114ea3745bb5096b7cd8392a50b14; ?>
<?php unset($__componentOriginal453114ea3745bb5096b7cd8392a50b14); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/home.css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/home.js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/albert/Workspace/FoxSoft/ShopFood/resources/views/home.blade.php ENDPATH**/ ?>