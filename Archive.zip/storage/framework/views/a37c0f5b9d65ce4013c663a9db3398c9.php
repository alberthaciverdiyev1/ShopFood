<?php $__env->startSection('content'); ?>
    <div class="max-w-4xl mx-auto bg-white p-6 rounded-lg shadow-md mt-10">
        <h2 class="text-2xl font-semibold mb-6 text-[#331111]">Şifrəni Bərpa Et</h2>

        <?php if(session('success')): ?>
            <div class="mb-4 p-4 bg-green-100 text-green-700 rounded-lg">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="mb-4 p-4 bg-red-100 text-red-700 rounded-lg">
                <ul class="list-disc pl-5">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('password.update')); ?>" method="POST" class="space-y-4">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="token" value="<?php echo e($token); ?>">
            <input type="hidden" name="email" value="<?php echo e($email); ?>">

            <div>
                <label class="block text-gray-700 font-medium mb-1">Yeni Şifrə</label>
                <input type="password" name="password"
                       class="w-full border border-gray-300 rounded-md px-3 py-2" required>
            </div>

            <div>
                <label class="block text-gray-700 font-medium mb-1">Şifrəni Təsdiqlə</label>
                <input type="password" name="password_confirmation"
                       class="w-full border border-gray-300 rounded-md px-3 py-2" required>
            </div>

            <div class="flex justify-end">
                <button type="submit" class="bg-[#F6A833] text-white px-4 py-2 rounded-md hover:bg-[#947D5B] transition">
                    Şifrəni Yenilə
                </button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/albert/Workspace/FoxSoft/ShopFood/resources/views/auth/reset_password.blade.php ENDPATH**/ ?>