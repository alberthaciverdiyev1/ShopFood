<section class="hero-gradient relative h-screen overflow-hidden">

    <div id="bannerWrapper" class="relative h-full w-full">
        <?php $__empty_1 = true; $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="banner-slide absolute inset-0 flex flex-col md:flex-row justify-between items-center px-4 transition-all duration-500"
                 style="transform: translateX(<?php echo e($index * 100); ?>%)">

                <img class="hidden md:block h-full absolute left-0 top-0 z-0 object-cover"
                     src="<?php echo e(asset('images/hero-left.png')); ?>" alt="">

                <div class="w-full md:w-[43%] flex flex-col gap-5 items-center md:items-start justify-center z-10 text-center md:text-left mt-10 md:mt-0 ml-12">
                    <h1 class="text-white"
                        style="font-family: 'Roboto', sans-serif; font-weight: 400; font-style: normal; font-size: 64px; line-height: 117%; letter-spacing: 0;">
                        <?php echo e($banner->title); ?>

                    </h1>
                    <?php if(!empty($banner->subtitle)): ?>
                        <p class="text-white"
                           style="font-family: 'Roboto', sans-serif; font-weight: 400; font-style: normal; font-size: 24px; line-height: 117%; letter-spacing: 0;">
                            <?php echo e($banner->subtitle); ?>

                        </p>
                    <?php endif; ?>
                    <?php if(!empty($banner->url)): ?>
                        <a href="<?php echo e($banner->url); ?>" target="_blank"
                           class="mt-3 px-5 py-2 bg-[#F6A833] text-white rounded hover:bg-[#947D5B] transition">
                            Learn More
                        </a>
                    <?php endif; ?>
                </div>

                
                <img class="w-full sm:w-[400px] md:w-[600px] h-auto py-9 z-20 object-contain mr-12"
                     src="<?php echo e(asset('storage/'.$banner->image)); ?>" alt="">
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="banner-slide absolute inset-0 flex flex-col md:flex-row justify-between items-center px-4">
                <h1 class="text-white">No banners found</h1>
            </div>
        <?php endif; ?>
    </div>

    <div class="dots absolute bottom-10 left-1/2 transform -translate-x-1/2 flex gap-2 z-20">
        <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="dot w-4 h-4 border rounded-full cursor-pointer" data-index="<?php echo e($index); ?>"></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</section>

<script>
    const slides = document.querySelectorAll('.banner-slide');
    const dots = document.querySelectorAll('.dot');
    let currentIndex = 0;

    function showSlide(index) {
        slides.forEach((slide, i) => {
            slide.style.transform = `translateX(${(i - index) * 100}%)`;
        });
        dots.forEach((dot, i) => {
            dot.classList.toggle('bg-white', i === index);
            dot.classList.toggle('border-white', i === index);
            dot.classList.toggle('bg-transparent', i !== index);
        });
    }

    dots.forEach(dot => {
        dot.addEventListener('click', () => {
            currentIndex = parseInt(dot.dataset.index);
            showSlide(currentIndex);
        });
    });

    let startX = 0;
    let endX = 0;
    const wrapper = document.getElementById('bannerWrapper');

    wrapper.addEventListener('touchstart', e => startX = e.touches[0].clientX);
    wrapper.addEventListener('touchmove', e => endX = e.touches[0].clientX);
    wrapper.addEventListener('touchend', () => {
        if (startX - endX > 50) {
            currentIndex = (currentIndex + 1) % slides.length;
        } else if (startX - endX < -50) {
            currentIndex = (currentIndex - 1 + slides.length) % slides.length;
        }
        showSlide(currentIndex);
    });

    setInterval(() => {
        currentIndex = (currentIndex + 1) % slides.length;
        showSlide(currentIndex);
    }, 3000);

    showSlide(currentIndex);
</script>
<?php /**PATH /home/albert/Workspace/FoxSoft/ShopFood/resources/views/components/hero.blade.php ENDPATH**/ ?>