<div class=" mx-auto px-4 ">
    <p class="font-bold ">Меню</p>
    <div class=" mt-4 flex flex-wrap gap-3">
        <div class="bg-[var(--color-secondary)]   rounded-2xl px-7 py-3">
            <span class="text-center text-white text-bold ">Заказ</span>

        </div>


        <div class="bg-[var(--color-secondary)] rounded-2xl px-7 py-3">
            <span class="text-center text-white text-bold "> История заказов
            </span>

        </div>
        <div class="bg-[var(--color-secondary)] rounded-2xl px-7 py-3">
            <span class="text-center text-white text-bold "> История заказов
            </span>

        </div><div class="bg-[var(--color-secondary)] rounded-2xl px-7 py-3">
            <span class="text-center text-white text-bold "> История заказов
            </span>

        </div><div class="bg-[var(--color-secondary)] rounded-2xl px-7 py-3">
            <span class="text-center text-white text-bold "> История заказов
            </span>

        </div><div class="bg-[var(--color-secondary)] rounded-2xl px-7 py-3">
            <span class="text-center text-white text-bold "> История заказов
            </span>

        </div>
    </div>
</div><?php /**PATH /home/albert/Workspace/ShopFood/resources/views/components/menu-banner.blade.php ENDPATH**/ ?>