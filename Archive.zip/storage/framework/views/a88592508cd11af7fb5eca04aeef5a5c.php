<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo $__env->yieldContent('title', 'Shop Food'); ?></title>

    <meta name="description" content="<?php echo $__env->yieldContent('meta_description', 'Buy fresh and tasty food online. Fast delivery and best prices.'); ?>">

    <meta name="robots" content="index, follow">

    <link rel="canonical" href="<?php echo e(url()->current()); ?>">

    <meta property="og:title" content="<?php echo $__env->yieldContent('title', 'Shop Food'); ?>">
    <meta property="og:description" content="<?php echo $__env->yieldContent('meta_description', 'Buy fresh and tasty food online. Fast delivery and best prices.'); ?>">
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo e(url()->current()); ?>">
    <meta property="og:image" content="<?php echo $__env->yieldContent('meta_image', asset('images/og-default.png')); ?>">

    <link rel="icon" href="<?php echo e(asset('favicon.ico')); ?>" type="image/x-icon">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.0/css/all.min.css" integrity="sha512-DxV+EoADOkOygM4IR9yXP8Sb2qwgidEmeqAEmDKIOfPRQZOWbXCzLC6vjbZyy0vPisbH2SyW27+ddLVCN+OMzQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>

    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body>

  <header>
    <?php if(!isset($hideNavbar) || !$hideNavbar): ?>
        <?php echo $__env->make('partials.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
</header>


    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <footer>
        <p>&copy; 2025 Shop Food. All rights reserved.</p>
    </footer>

    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>

    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH /home/albert/Workspace/ShopFood/resources/views/layouts/app.blade.php ENDPATH**/ ?>