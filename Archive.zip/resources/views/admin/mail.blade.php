
<p>Salam, {{ $link }} üzərindən hesabınızı aktivləşdirə bilərsiniz.</p>
<a href="{{ $link }}">Hesabı aktivləşdir</a>
