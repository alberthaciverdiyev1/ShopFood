<div class=" mx-auto px-24 ">
    <p class="font-bold ">Меню</p>
    <div class=" mt-4 flex flex-wrap gap-3">
        <div class="bg-[var(--color-warning)]   rounded-2xl px-7 py-3">
            <a href="{{route('basket.list')}}">
                <span class="text-center text-white text-bold ">Заказ</span>

            </a>
        </div>


        <div class="bg-[var(--color-warning)] rounded-2xl px-7 py-3">
            <a href="{{route('profile')}}">
                <span class="text-center text-white text-bold "> История заказов
            </span></a>
        </div>
        <div class="bg-[var(--color-warning)] rounded-2xl px-7 py-3">
            <a href="{{route('privacy-policy.home')}}">
                <span class="text-center text-white text-bold "> Privacy and Policy</span>
            </a>

        </div>

        <div class="bg-[var(--color-warning)] rounded-2xl px-7 py-3">
            <span class="text-center text-white text-bold "> История заказов
            </span>

        </div>
        <div class="bg-[var(--color-warning)] rounded-2xl px-7 py-3">
            <span class="text-center text-white text-bold "> История заказов
            </span>

        </div>
    </div>
</div>
